#!/usr/bin/env bash
docker build -t chrispydizzle/awsnetcore-worker .
