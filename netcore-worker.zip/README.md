AWS CodeStar Sample ASP.NET Core Web Service (Well, now it's a Worker Service)
==================================================

I piggybacked off of the Core Web Services project to create a worker service very similar to what I might have done 
on a previous engagement.  
